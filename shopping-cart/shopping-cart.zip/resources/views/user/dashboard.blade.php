@extends('layouts.dashboard')
@section('user')
    <div class="container" style="">
        <div class="py-4 px-4">
            <h3>Welcome to Dashboard</h3>
        </div>
    </div>
@endsection
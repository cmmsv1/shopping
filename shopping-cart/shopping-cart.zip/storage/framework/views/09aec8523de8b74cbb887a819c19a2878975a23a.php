<?php
    $total = 0;
?>
<?php if(count($carts)>0): ?>
    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
    <li class="pr-cart-item">
        <input type="hidden" value="<?php echo e($cart->products->id); ?>" class="productcart_id"> 
        <div class="product-image">
            <figure><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($cart->products->image); ?>" alt=""></figure>
        </div>
        <div class="product-name">
            <a class="link-to-product" href="<?php echo e(route('product.detail',$cart->products->slug)); ?>"><?php echo e($cart->products->name); ?></a>
        </div>
        <div class="price-field produtc-price">
            <p class="price">
                <?php
                    echo number_format($cart->products->regular_price, 0, ',', '.').'đ';
                ?>
            </p>
        </div>
        <div class="quantity">
            <div class="quantity-input">
                <input type="text"  class="product_quantity" value="<?php echo e($cart->quantity); ?>" data-max="<?php echo e($cart->products->quantity); ?>" pattern="[0-9]*" >									
                <span class="btn btn-increase changequantity"></span>
                <span class="btn btn-reduce changequantity"></span>
            </div>
        </div>
        
        <div class="price-field sub-total">
            <p class="price">
                <?php
                    echo number_format($cart->products->regular_price * $cart->quantity, 0, ',', '.').'đ';
                ?>
            </p>
        </div>
        <div class="delete">
            <a href="#" class="btn btn-delete remove-cart" title="">
                <span>Delete from your cart</span>
                <i class="fa fa-times-circle" aria-hidden="true"></i>
            </a>
        </div>
    </li>	
    <?php
        $total = $total + $cart->products->regular_price * $cart->quantity;
    ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

<?php else: ?> 
    <div style="padding: 40px">
        <p style="text-align: center; font-size: 15px">Giỏ hàng của bạn đang trống.....</p>
    </div>
<?php endif; ?>		
<div class="summary">
    <div class="order-summary" style="margin-top: 20px">
        <p class="summary-info"><span class="title">Tổng tiền</span><b class="index"><?php echo number_format($total, 0, ',', '.').'đ'; ?></b></p>
        <p class="summary-info"><span class="title">Phí vận chuyển</span><b class="index">Miễn phí</b></p>
        <p class="summary-info total-info "><span class="title">Tổng</span><b class="index"><?php echo number_format($total, 0, ',', '.').'đ';?></b></p>
    </div>
    <div class="checkout-info">
        <label class="checkbox-field">
            <input class="frm-input " name="have-code" id="have-code" value="" type="checkbox"><span>I have promo code</span>
        </label>
        <a class="btn btn-checkout" href="<?php echo e(route('checkout')); ?>">Thanh toán</a>
        <a class="link-to-shop" href="<?php echo e(route('shop')); ?>">Tiếp tục mua sắm<i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a>
    </div>
    <div class="update-clear">
        
    </div>
</div><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/cart/itemCart.blade.php ENDPATH**/ ?>
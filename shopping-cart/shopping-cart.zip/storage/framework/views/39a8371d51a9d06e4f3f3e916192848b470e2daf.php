
<?php $__env->startSection('content'); ?>
<main id="main" class="main-site">

    <div class="container">

        <div class="wrap-breadcrumb">
            <ul>
                <li class="item-link"><a href="<?php echo e(route('home')); ?>" class="link">Trang chủ</a></li>
                <li class="item-link"><span>Giỏ hàng</span></li>
            </ul>
        </div>
        <div class=" main-content-area">

            <div class="wrap-iten-in-cart">
                <h3 class="box-title">SẢN PHẨM</h3>
                
                <ul class="products-cart">
                    
                    <?php echo $__env->make('cart.itemCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>						
                </ul>
            </div>

            

            

        </div><!--end main content area-->
    </div><!--end container-->

</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {

        function getDataCart() {
            $.ajax({
                url: "<?php echo e(route('cart.getDataCarts')); ?>",
                success: function (response) {
                    $('.products-cart').html(response);
                }
            });
        };

        $(document).on('click','.remove-cart',function (e) { 
            e.preventDefault();
            var product_id = $(this).closest('.pr-cart-item').find('.productcart_id').val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "post",
                url: "<?php echo e(route('cart.remove')); ?>",
                data: {
                    product_id: product_id
                },
                success: function (response) {
                    getDataCart();
                    swal({
                        title: "Success!",
                        text: response.message,
                        icon: "success",
                    });
                    $('.cart_count').html(response.cart_count+ ' items');
                }
            });
        });

        $(document).on( "click", ".changequantity", function(e)  { 
            e.preventDefault();
            var product_id = $(this).closest('.pr-cart-item').find('.productcart_id').val();
            var product_quantity = $(this).parent().find('.product_quantity').val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('cart.updateQuantity')); ?>",
                data: {
                    product_id: product_id,
                    product_quantity: product_quantity
                },
                success: function (response) {
                    getDataCart();
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/cart/index.blade.php ENDPATH**/ ?>
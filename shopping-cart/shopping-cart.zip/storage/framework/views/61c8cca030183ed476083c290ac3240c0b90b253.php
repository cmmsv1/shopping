<div class="tab-content-item active" id="fashion_<?php echo e($category_parent_id); ?>">
    <div class="wrap-products slide-carousel owl-carousel style-nav-1 equal-container" data-items="5" data-loop="false" data-nav="true" data-dots="false" data-responsive='{"0":{"items":"1"},"480":{"items":"2"},"768":{"items":"3"},"992":{"items":"4"},"1200":{"items":"5"}}' >
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
            <div class="product product-style-2 equal-elem ">
                <div class="product-thumnail">
                    <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="<?php echo e($item->name); ?>">
                        <figure><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->image); ?>" width="800" height="800" alt="<?php echo e($item->name); ?>"></figure>
                    </a>
                    <div class="group-flash">
                        <span class="flash-item new-label">new</span>
                    </div>
                    <div class="wrap-btn">
                        <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="function-link">quick view</a>
                    </div>
                </div>
                <div class="product-info">
                    <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="product-name"><span><?php echo e($item->name); ?></span></a>
                    <div class="wrap-price"><span class="product-price">$250.00</span></div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/home/item.blade.php ENDPATH**/ ?>
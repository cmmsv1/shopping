<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th class="text-center">ID</th>
            <th class="text-center">Name</th>
            <th class="text-center">Email</th>
            <th class="text-center">Role</th>
            <th class="text-center">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
            <tr>
                <td class="text-center"><?php echo e($item->id); ?></td>
                <td class="text-center"><?php echo e($item->name); ?></td>
                <td class="text-center"><?php echo e($item->email); ?></td>
                <?php if($item->type == 'ADMIN'): ?>
                    <td class="text-center"><span style="padding: 10px;font-weight: bolder; color: rgb(226, 14, 96)">ADMIN</span></td>
                <?php else: ?>
                    <td class="text-center"><span style="padding: 10px;font-weight: bolder; color: rgb(83, 240, 104)">USER</span></td>
                <?php endif; ?>
                <td class="text-center">
                    <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-primary edit"  style="margin: 0px 15px">
                        <i class="ti-pencil"></i>
                    </a>
                    <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-danger remove">
                        <i class="ti-trash"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $users->links(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/admin/users/userdata.blade.php ENDPATH**/ ?>
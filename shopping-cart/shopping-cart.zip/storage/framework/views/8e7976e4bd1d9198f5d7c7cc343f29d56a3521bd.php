
<?php $__env->startSection('admin'); ?>
<div class="container">
    <div class="py-4 px-4">
        <h3 class="text-center">Chi tiết đơn hàng</h3>
        <a href="<?php echo e(route('admin.order')); ?>" class="btn btn-primary"><i class="ti-arrow-left"></i></a>
        <div class="row mt-5">
            <div class="col-lg-10 mx-auto">
                <div class="row">
                    <div class="col-lg-5">
                        <h4 class="text-center">Thông tin khách hàng</h4>
                        <form method="post" id="changeStatus">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="order_id" value="<?php echo e($order->id); ?>">
                            <div class="form-group">
                                <label for="my-input">Họ và tên</label>
                                <input id="my-input" class="form-control" type="text" value="<?php echo e($order->name); ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label for="my-input">Số điện thoại</label>
                                <input id="my-input" class="form-control" type="number" value="<?php echo e($order->phone); ?>" disabled>
                            </div>
                            <div class="form-group">                          
                            <div class="form-group">
                                    <label for="my-input">Địa chỉ:</label>
                                    <textarea id="my-textarea" class="form-control" disabled rows="3"><?php echo e($order->house.','.$order->ward.','.$order->district.','.$order->province); ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="my-select">Trạng thái</label>
                                <select id="my-select" class="form-control" name='status'>
                                    <?php if($order->status == '0'): ?>
                                        <option value="0" selected>Pending</option>
                                        <option value="1">Completed</option>
                                    <?php else: ?> 
                                        <option value="0">Pending</option>
                                        <option value="1" selected>Completed</option>
                                    <?php endif; ?>                           
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Cập nhật</button>
                        </form>
                    </div>
                    <div class="col-lg-7">
                        <h4 class="text-center">Sản phẩm mua</h4>
                        <table class="table table-striped table-bordered mt-3">
                            <thead>
                                <tr>
                                    <td>Tên sản phẩm</td>
                                    <td>Số lượng</td>
                                    <td>Giá</td>
                                    <td>Ảnh</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->products->name); ?></td>
                                        <td><?php echo e($item->quantity); ?></td>
                                        <td><?php echo e($item->products->regular_price); ?></td>
                                        <td><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->products->image); ?>" alt=""></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                        <div style="margin-top: 20px"><span>Tổng tiền: $<?php echo e($order->total); ?></span></div>
                    </div>
                </div>
                
            </div>
            
        </div>
        
</div>
<script>
    $(document).ready(function () {
        
        $('#changeStatus').submit(function (e) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            e.preventDefault();
            status = $('#my-select').val();
            id = $('#order_id').val();
            $.ajax({
                type: "post",
                url: "/admin/order/detail/update/"+id,
                data: {status:status},
                success: function (response) {
                    swal({
                        title: "Success!",
                        text: response.message,
                        icon: "success",
                    });
                }
            });
        });
        
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>
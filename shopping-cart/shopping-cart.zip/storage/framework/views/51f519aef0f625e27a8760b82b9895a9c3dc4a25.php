
<?php $__env->startSection('content'); ?>
<main id="main" class="main-site left-sidebar">

    <div class="container">

        <div class="wrap-breadcrumb">
            <ul>
                <li class="item-link"><a href="<?php echo e(route('home')); ?>" class="link">home</a></li>
                <li class="item-link"><span>Search</span></li>
                <li class="item-link"><span><?php echo e($search); ?></span></li>
                <input type="hidden" id="search_top_name" value="<?php echo e($search); ?>">
            </ul>
        </div>
        <div class="row">

            <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12 main-content-area">

                <div class="wrap-shop-control">

                    <h1 class="shop-title">Digital & Electronics</h1>

                    <div class="wrap-right">

                        <div class="sort-item orderby ">
                            <select name="orderby" class="use-chosen" id="sort">
                                <option value="default" selected="selected">Default sorting</option>
                                <option value="date">Sort by newness</option>
                                <option value="price">Sort by price: low to high</option>
                                <option value="price-desc">Sort by price: high to low</option>
                            </select>
                        </div>

                        <div class="sort-item product-per-page">
                            <select name="post-per-page" class="use-chosen" id="paginate-page">
                                <option value="12" selected="selected">12 per page</option>
                                <option value="15">15 per page</option>
                                <option value="21">21 per page</option>
                                <option value="34">34 per page</option>
                            </select>
                        </div>

                        <div class="change-display-mode">
                            <a href="#" class="grid-mode display-mode active"><i class="fa fa-th"></i>Grid</a>
                            <a href="list.html" class="list-mode display-mode"><i class="fa fa-th-list"></i>List</a>
                        </div>

                    </div>

                </div><!--end wrap shop control-->

                <div class="row" id="products">
                    <?php echo $__env->make('shop.read', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <input type="hidden" value="1" id="hidden_page" >
            </div><!--end main products area-->
        </div><!--end row-->

    </div><!--end container-->

</main>
<script>
   $(document).ready(function () {
       var search = $('#search_top_name').val();
       $('#search_top').val(search);
   });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/search.blade.php ENDPATH**/ ?>
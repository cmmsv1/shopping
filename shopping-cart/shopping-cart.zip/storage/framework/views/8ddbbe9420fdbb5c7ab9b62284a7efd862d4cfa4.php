<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên khách hàng</th>
            <th>Số điện thoại</th>
            <th>Thành tiền</th>
            <th>Hình thức thanh toán</th>
            
            <th>Thời gian đặt hàng</th>
            <th>Trạng thái</th>
            <th>Chi tiết</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->phone); ?></td>
                <td><?php echo number_format($item->total, 0, ',', '.').'đ';?></td>
                <?php if($item->payment_method == 0): ?>
                    <td>Thanh toán khi nhận hàng</td>
                <?php else: ?>
                    <td><?php echo e($item->payment_method); ?></td>
                <?php endif; ?>
                
                <td><?php echo e($item->created_at); ?></td>
                <?php if($item->status == 0): ?>
                    <td><span style="color:#fff;padding: 10px;background-color: rgb(79,83,79)">Đơn hàng mới</span></td>
                <?php elseif($item->status == 1): ?>
                    <td><span style="color:#fff;padding: 10px;background-color: rgb(56, 201, 75)">Đã được xác nhận</span></td>
                <?php elseif($item->status == 2): ?>
                    <td><span style="color:#fff;padding: 10px;background-color: rgb(85, 114, 231)">Đang giao hàng</span></td>
                <?php elseif($item->status == 3): ?>
                    <td><span style="color:#fff;padding: 10px;background-color: rgb(228, 22, 239)">Giao hàng thành công</span></td>
                <?php else: ?> 
                    <td><span style="color:#fff;padding: 10px;background-color: rgb(231, 64, 81)">Đã bị huỷ bỏ</span></td>
                <?php endif; ?>
                <td><a href="<?php echo e(route('admin.orders.detail',$item->id)); ?>" class="btn btn-primary">Chi tiết</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $orders->links(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/admin/orders/item.blade.php ENDPATH**/ ?>
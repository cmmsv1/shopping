<table class="table table-striped table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên khách hàng</th>
            <th>Số điện thoại</th>
            <th>Thành tiền</th>
            <th>Trạng thái</th>
            <th>Chi tiết</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->phone); ?></td>
                <td><?php echo e($item->total); ?></td>
                <?php if($item->status == 0): ?>
                    <td><span style="color:#fff;padding: 10px;background-color: rgb(236, 152, 56)">Pending</span></td>
                <?php else: ?>
                    <td><span style="color:#fff;padding: 10px;background-color: rgb(56, 201, 75)">Completed</span></td>
                <?php endif; ?>
                <td><a href="<?php echo e(route('admin.order.detail',$item->id)); ?>" class="btn btn-primary">Chi tiết</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $orders->links(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/admin/order/item.blade.php ENDPATH**/ ?>
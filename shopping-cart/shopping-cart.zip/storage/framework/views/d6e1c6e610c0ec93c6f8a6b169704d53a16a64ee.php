
<?php $__env->startSection('admin'); ?>
    <div class="container">
        <div class="px-5 py-5">  
            <h3 class="text-center mb-5">Thay đổi logo</h3>    
            <form action="" method="post" id="logo">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Banner 1:</label>
                    <input class="form-control" name="image1" style="width: 400px" type="file" onChange="readURL(this);">
                    <img id="img1" class="mt-3" style="width: 100px;height: 50px;display: none" alt="">
                    
                </div> 
                <div class="form-group">
                    <label for="">Banner 2:</label>
                    <input class="form-control" name="image2" style="width: 400px" type="file" onChange="readURL(this);">
                    <img id="img2" class="mt-3" style="width: 100px;height: 50px;display: none" alt="">
                    
                </div>
                <div class="form-group">
                    <label for="">Banner 3:</label>
                    <input class="form-control" name="image3" style="width: 400px" type="file" onChange="readURL(this);">
                    <img id="img3" class="mt-3" style="width: 100px;height: 50px;display: none" alt="">
                    
                </div>
                <div class="form-group">
                    <label for="">Banner 4:</label>
                    <input class="form-control" name="image4" style="width: 400px" type="file" onChange="readURL(this);">
                    <img id="img4" class="mt-3" style="width: 100px;height: 50px;display: none" alt="">
                    
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>             
        </div>
    </div>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $($(input).next()[0]).show();
                    $($(input).next()[0]).attr('src', e.target.result);
                    $($(input).next().next()[0]).hide();
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <script>
        $(document).ready(function () {
            $('#logo').submit(function (e) { 
                e.preventDefault();
                var data = new FormData(this);
                $.ajax({
                    type: "post",
                    url: "/admin/custom/banner/update",
                    data: data,
                    processData: false,
                    dataType: 'json',
                    contentType: false,
                    success: function (response) {
                        console.log(response);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/admin/custom/banner.blade.php ENDPATH**/ ?>

<?php $__env->startSection('admin'); ?>
    <div class="container">
        <div class="py-5 px-4">
            <h3 class="text-center">Quản lý danh mục</h3>
            <div class="row mt-5">
                <div>
                    <button type="button" id="btn-add" style="float: right;" class="btn btn-success ">Thêm mới</button>
                </div>
                <div class="col-lg-12">
                    <h4 class="text-center">Danh sách danh mục</h4>
                    <div class="table-responsive mt-4">
                        <table class="table table-striped table-bordered ">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody id="tbody">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                                         
                                        <tr>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            
                                            <td>
                                                <a data-href="<?php echo e($item->id); ?>" class="btn btn-warning edit" style="margin: 0px 30px">Sửa</a>
                                                <a data-href="<?php echo e($item->id); ?>" class="btn btn-danger remove">Xoá</a>
                                            </td>
                                                
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                        </table>
                    </div>
                </div>

                
                <div class="modal fade" id="formModal" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="formModalLabel">Thêm danh mục</h4>
                            </div>
                            <div class="modal-body">
                                <form id="myForm" name="myForm" class="form-horizontal" novalidate="">
                                    <div class="form-group">
                                        <label>Tên danh mục</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                                placeholder="Enter name" value="">
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" id="btn-save">Lưu lại
                                </button>
                                <input type="hidden" id="todo_id" name="todo_id" value="0">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>

<script>
    $(document).ready(function () {

        $('#btn-add').click(function () {
            $('#myForm').trigger("reset");
            $('#formModal').modal('show');
        });

        // edit category
        $('.edit').click(function (e) { 
            e.preventDefault();
            $('#formModal').modal('show');
            $('#btn-save').html("Cập nhật");
            let id = $(this).data('href');
            $.get("/admin/categories/edit/"+id,
                function (data) {                   
                    $('#name').val(data.name);
                    $('#todo_id').val(data.id);            
                },
            );
        });

        // update category
        $('#btn-save').click(function (e) { 
            e.preventDefault();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            var id = $('#todo_id').val();
            var name = $('#name').val();
            $.ajax({
                type: "PUT",
                url: "/admin/categories/update/"+id,
                data: {
                    name: name,
                },
                success: function (response) {
                    console.log(response);
                }
            });
        });

        //ADD category
        $('#btn-save').click(function (e) { 
            e.preventDefault();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('admin.categories.add')); ?>",
                data: {
                    name: name,
                },
                success: function (response) {
                    $('#tbody').append(`
                        <tr>
                            <td>${response}</td>
                            <td>${name}</td>
                            <td>
                                <a data-href="${response}" class="btn btn-warning edit" style="margin: 0px 30px">Sửa</a>
                                <a data-href="${response}" class="btn btn-danger remove">Xoá</a>
                            </td>
                                
                        </tr>
                    `);
                    $('#name').val('');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/admin/categories.blade.php ENDPATH**/ ?>
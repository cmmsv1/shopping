<ul class="product-list grid-products equal-container row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
        <li class="col-lg-4 col-md-6 col-sm-6 col-xs-6 ">
            <div class="product product-style-3 equal-elem ">
                <div class="product-thumnail">
                    <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="<?php echo e($item->name); ?>">
                        <figure><img style="width: 260px;height: 260px;" src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>"></figure>
                    </a>
                </div>
                <div class="product-info">
                    <a href="#" class="product-name"><span><?php echo e($item->name); ?></span></a>
                    <div class="wrap-price">
                        <span class="product-price">
                            <?php
                                echo number_format($item->regular_price, 0, ',', '.').'đ';
                            ?>
                        </span>
                    </div>
                    <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="btn add-to-cart">Xem chi tiết</a>
                </div>
            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<div id="paginate">
    <?php echo $products->links(); ?>

</div><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/shop/read.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="px-5 py-5">
            <h3 class="text-center">Infomation</h3>
            <?php if(!empty($address)): ?>
                <form method="post" id="info">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="province">Tỉnh/Thành phố:*</label>
                        <input id="province" class="form-control" type="text" name="province"
                            value="<?php echo e($address->province); ?>" placeholder="Nhập Tỉnh/Thành phố ...">
                        <span style="color: red;font-size: 13px; padding:5px 10px;" class="err province_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="district">Quận/Huyện:<span>*</span></label>
                        <input id="district" class="form-control" type="text" name="district"
                            value="<?php echo e($address->district); ?>" placeholder="Nhập Quận/Huyện... ">
                        <span style="color: red;font-size: 13px; padding:5px 10px;" class="err district_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="ward">Phường/Xã:*</label>
                        <input id="ward" class="form-control" type="text" name="ward"
                            value="<?php echo e($address->ward); ?>" placeholder="Nhập Phường/Xã...">
                        <span style="color: red;font-size: 13px; padding:5px 10px;" class="err ward_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="house">Tên đường/Toà nhà/Số nhà :<span>*</span></label>
                        <input id="house" class="form-control" type="text" name="house"
                            value="<?php echo e($address->house); ?>" placeholder="Nhập số nhà ....">
                        <span style="color: red;font-size: 13px; padding:5px 10px;" class="err house_error"></span>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            <?php else: ?>
                <form method="post" id="info">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="province">Tỉnh/Thành phố:*</label>
                        <input id="province" class="form-control" type="text" name="province" value=""
                            placeholder="Nhập Tỉnh/Thành phố ...">
                        <span style="color: red;font-size: 13px; padding:5px 10px;" class="err province_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="district">Quận/Huyện:<span>*</span></label>
                        <input id="district" class="form-control" type="text" name="district" value=""
                            placeholder="Nhập Quận/Huyện... ">
                        <span style="color: red;font-size: 13px; padding:5px 10px;" class="err district_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="ward">Phường/Xã:*</label>
                        <input id="ward" class="form-control" type="text" name="ward" value=""
                            placeholder="Nhập Phường/Xã...">
                        <span style="color: red;font-size: 13px; padding:5px 10px;" class="err ward_error"></span>
                    </div>
                    <div class="form-group">
                        <label for="house">Tên đường/Toà nhà/Số nhà :<span>*</span></label>
                        <input id="house" class="form-control" type="text" name="house" value=""
                            placeholder="Nhập số nhà ....">
                        <span style="color: red;font-size: 13px; padding:5px 10px;" class="err house_error"></span>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            <?php endif; ?>

        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#info').submit(function(e) {
                e.preventDefault();
                var data = new FormData(this);
                $.ajax({
                    type: "post",
                    url: "<?php echo e(route('user.address.update')); ?>",
                    data: data,
                    processData: false,
                    dataType: 'json',
                    contentType: false,
                    success: function(response) {
                        swal({
                            title: "Success!",
                            text: response.message,
                            icon: "success",
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/address/index.blade.php ENDPATH**/ ?>
<header id="header" class="header header-style-1">
    <div class="container-fluid">
        <div class="row">
            <div class="topbar-menu-area">
                <div class="container">
                    <div class="topbar-menu left-menu">
                        <ul>
                            <li class="menu-item" >
                                <a title="Hotline: (+123) 456 789" href="#" ><span class="icon label-before fa fa-mobile"></span>Hotline: (+123) 456 789</a>
                            </li>
                        </ul>
                    </div>
                    <div class="topbar-menu right-menu">
                        <ul>
                            <li class="menu-item lang-menu menu-item-has-children parent">
                                <a title="English" href="#"><span class="img label-before"><img src="<?php echo e(asset('assets/images/lang-en.png')); ?>" alt="lang-en"></span>English<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                <ul class="submenu lang" >
                                    <li class="menu-item" ><a title="hungary" href="#"><span class="img label-before"><img src="<?php echo e(asset('assets/images/lang-hun.png')); ?>" alt="lang-hun"></span>Hungary</a></li>
                                    <li class="menu-item" ><a title="german" href="#"><span class="img label-before"><img src="<?php echo e(asset('assets/images/lang-ger.png')); ?>" alt="lang-ger" ></span>German</a></li>
                                    <li class="menu-item" ><a title="french" href="#"><span class="img label-before"><img src="<?php echo e(asset('assets/images/lang-fra.png')); ?>" alt="lang-fre"></span>French</a></li>
                                    <li class="menu-item" ><a title="canada" href="#"><span class="img label-before"><img src="<?php echo e(asset('assets/images/lang-can.png')); ?>" alt="lang-can"></span>Canada</a></li>
                                </ul>
                            </li>
                            <li class="menu-item menu-item-has-children parent" >
                                <a title="Dollar (USD)" href="#">Dollar (USD)<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                <ul class="submenu curency" >
                                    <li class="menu-item" >
                                        <a title="Pound (GBP)" href="#">Pound (GBP)</a>
                                    </li>
                                    <li class="menu-item" >
                                        <a title="Euro (EUR)" href="#">Euro (EUR)</a>
                                    </li>
                                    <li class="menu-item" >
                                        <a title="Dollar (USD)" href="#">Dollar (USD)</a>
                                    </li>
                                </ul>
                            </li>

                            <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->type === 'ADMIN'): ?>
                                        <li class="menu-item menu-item-has-children parent" >
                                            <a title="Dollar (USD)" href="#">My accout (<?php echo e(Auth::user()->name); ?>)<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                            <ul class="submenu curency" >
                                                <li class="menu-item" >
                                                    <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                                                </li>
                                                
                                                <li class="menu-item" >
                                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout_form').submit()">Logout</a>
                                                </li>
                                                <form id="logout_form" action="<?php echo e(route('logout')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </ul>
                                        </li>
                                    <?php else: ?> 
                                        <li class="menu-item menu-item-has-children parent" >
                                            <a href="#">My accout (<?php echo e(Auth::user()->name); ?>)<i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                            <ul class="submenu curency" >
                                                <li class="menu-item" >
                                                    <a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a>
                                                </li>
                                                <li class="menu-item" >
                                                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout_form').submit()">Logout</a>
                                                </li>
                                                <form id="logout_form" action="<?php echo e(route('logout')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                            </ul>
                                        </li>	
                                    <?php endif; ?>								
                                <?php else: ?>
                                    <li class="menu-item" ><a title="Register or Login" href="<?php echo e(route('login')); ?>">Login</a></li>
                                    <li class="menu-item" ><a title="Register or Login" href="<?php echo e(route('register')); ?>">Register</a></li>
                                <?php endif; ?>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="container">
                <div class="mid-section main-info-area">

                    <div class="wrap-logo-top left-section">
                        <?php if($logo): ?>
                            
                        <a href="index.html" class="link-to-home"><img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($logo); ?>" alt="mercado"></a>
                        <?php endif; ?>
                    </div>

                    <?php echo $__env->make('headerSearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="wrap-icon right-section">
                        <div class="wrap-icon-section wishlist">
                            <a href="#" class="link-direction">
                                <i class="fa fa-heart" aria-hidden="true"></i>
                                <div class="left-info">
                                    <span class="index">0 item</span>
                                    <span class="title">Wishlist</span>
                                </div>
                            </a>
                        </div>
                        <div class="wrap-icon-section minicart">
                            <a href="<?php echo e(route('cart')); ?>" class="link-direction">
                                <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                                <div class="left-info">

                                        <span class="index cart_count"><?php echo e($cart_count); ?> items</span>

                                    
                                    <span class="title">CART</span>
                                </div>
                            </a>
                        </div>
                        <div class="wrap-icon-section show-up-after-1024">
                            <a href="#" class="mobile-navigation">
                                <span></span>
                                <span></span>
                                <span></span>
                            </a>
                        </div>
                    </div>

                </div>
            </div>

            <div class="nav-section header-sticky">
                <div class="header-nav-section">
                    <div class="container">
                        <ul class="nav menu-nav clone-main-menu" id="mercado_haead_menu" data-menuname="Sale Info" >
                            <li class="menu-item"><a href="#" class="link-term">Weekly Featured</a><span class="nav-label hot-label">hot</span></li>
                            <li class="menu-item"><a href="#" class="link-term">Hot Sale items</a><span class="nav-label hot-label">hot</span></li>
                            <li class="menu-item"><a href="#" class="link-term">Top new items</a><span class="nav-label hot-label">hot</span></li>
                            <li class="menu-item"><a href="#" class="link-term">Top Selling</a><span class="nav-label hot-label">hot</span></li>
                            <li class="menu-item"><a href="#" class="link-term">Top rated items</a><span class="nav-label hot-label">hot</span></li>
                        </ul>
                    </div>
                </div>

                <div class="primary-nav-section">
                    <div class="container">
                        <ul class="nav primary clone-main-menu" id="mercado_main" data-menuname="Main menu" >
                            <li class="menu-item home-icon <?php echo e(Request::path()=='/'?'active':''); ?>">
                                <a href="<?php echo e(route('home')); ?>" class="link-term mercado-item-title"><i class="fa fa-home" aria-hidden="true"></i></a>
                            </li>
                            <li class="menu-item <?php echo e(Request::path()=='about'?'active':''); ?>">
                                <a href="<?php echo e(route('about')); ?>" class="link-term mercado-item-title">About Us</a>
                            </li>
                            <li class="menu-item <?php echo e(Request::path()=='shop'?'active':''); ?>">
                                <a href="<?php echo e(route('shop')); ?>" class="link-term mercado-item-title">Shop</a>
                            </li>
                            <li class="menu-item <?php echo e(Request::path()=='cart'?'active':''); ?>">
                                <a href="<?php echo e(route('cart')); ?>" class="link-term mercado-item-title">Cart</a>
                            </li>
                            <li class="menu-item <?php echo e(Request::path()=='checkout'?'active':''); ?>">
                                <a href="<?php echo e(route('checkout')); ?>" class="link-term mercado-item-title">Checkout</a>
                            </li>
                            <li class="menu-item <?php echo e(Request::path()=='contact'?'active':''); ?>" >
                                <a href="<?php echo e(route('contact')); ?>" class="link-term mercado-item-title">Contact Us</a>
                            </li>																	
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/page/header.blade.php ENDPATH**/ ?>
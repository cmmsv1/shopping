
<?php $__env->startSection('user'); ?>
    <div class="container" style="">
        <div class="py-4 px-4">
            <h3>Welcome to Dashboard</h3>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/user/dashboard.blade.php ENDPATH**/ ?>
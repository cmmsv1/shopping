
<?php $__env->startSection('user'); ?>
    <div class="container">
        <div class="py-4 px-4">
            <h3 class="text-center">Thông tin cá nhân</h3>
                <div class="row">
                    <div class="col-lg-6">
                        <h5 class="text-center">Thông tin user</h5>
                        <form method="POST" id="formProfile">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Họ và tên</label>
                                <input type="text" class="form-control" name="name" placeholder="Họ và tên ..." value="<?php echo e($user->name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="">Email</label>
                                <input type="email" class="form-control" name="email" placeholder="Email ..." value="<?php echo e($user->email); ?>">
                            </div>
                            <div class="form-group">
                                <label for="">Phone</label>
                                <input type="number" class="form-control" name="phone" placeholder="Phone ..." value="<?php echo e($user->phone); ?>"> 
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Cập nhật</button>
                        </form>
                        
                    </div>
                    <div class="col-lg-6">
                        <h5 class="text-center">Change password</h5>
                        <form action="" id="changePass">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Current Password</label>
                                <input type="password" class="form-control" name="current_password" autocomplete="off" placeholder="Current Password...">
                                <span style="color: red;font-size: 13px; padding:5px 10px;" class="err current_pass_error"></span>
                            </div>
                            <div class="form-group">
                                <label for="">Password</label>
                                <input type="password" class="form-control" name="password" placeholder="Password..." >
                                <span style="color: red;font-size: 13px; padding:5px 10px;" class="err pass_error"></span>
                            </div>
                            <div class="form-group">
                                <label for="">Confirm Password</label>
                                <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password..." >
                                <span style="color: red;font-size: 13px; padding:5px 10px;" class="err confirm_pass_error"></span>
                            </div>
                            <button class="btn btn-primary">Change password</button>
                        </form>
                        
        </div>
    </div>

    <script>
        $(document).ready(function () {
            function reset(){
                $('.current_pass_error').text('')
                $('.pass_error').text('')
                $('.confirm_pass_error').text('')
            }
            $('#formProfile').submit(function (e) { 
                e.preventDefault();
                var formData = new FormData(this);
                $.ajax({
                    type: "POST",
                    url: "/user/profile/updateProfile",
                    data: formData,
                    processData: false,
                    dataType: 'json',
                    contentType: false,
                    success: function (response) {
                        swal({
                            title: "Success!",
                            text: response.message,
                            icon: "success",
                        });
                    }
                });
            });
            $('#changePass').submit(function (e) { 
                e.preventDefault();
                var formData = new FormData(this);
                $.ajax({
                    type: "POST",
                    url: "/user/profile/changePass",
                    data: formData,
                    processData: false,
                    dataType: 'json',
                    contentType: false,
                    success: function (response) {
                        if(response.current_pass){
                            reset();
                            $('.current_pass_error').text(response.current_pass)
                        }else if(response.pass){
                            reset();
                            $('.pass_error').text(response.pass)
                        }else if(response.confirm_pass){
                            reset();
                            $('.confirm_pass_error').text(response.confirm_pass)
                        }
                        if(response.message){
                            swal({
                                title: "Success!",
                                text: response.message,
                                icon: "success",
                            }).then(()=>{
                                reset();
                            });
                            
                        }
                    },
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/user/profile/index.blade.php ENDPATH**/ ?>
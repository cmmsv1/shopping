<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Pay $1000</title>
    <script src="https://www.paypal.com/sdk/js?client-id=<?php echo e(env('PAYPAL_SANDBOX_CLIENT_ID')); ?>"></script>
</head>
<body>
    <a class="btn btn-primary m-3" href="<?php echo e(route('processTransaction')); ?>">Pay $1000</a>
    <?php if(\Session::has('error')): ?>
        <div class="alert alert-danger"><?php echo e(\Session::get('error')); ?></div>
        <?php echo e(\Session::forget('error')); ?>

    <?php endif; ?>
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success"><?php echo e(\Session::get('success')); ?></div>
        <?php echo e(\Session::forget('success')); ?>

    <?php endif; ?>
</body>
</html><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/transaction.blade.php ENDPATH**/ ?>
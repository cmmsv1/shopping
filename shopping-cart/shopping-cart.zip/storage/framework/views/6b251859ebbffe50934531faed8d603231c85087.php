<?php if(count($sliders)>0): ?>
<div class="table-responsive mt-4">
    <table class="table table-striped table-bordered ">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Subtitle</th>
                <th>Price</th>
                <th>Status</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody id="tbody">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                                         
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e($item->subtitle); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td><img src="<?php echo e(asset('assets/images/sliders')); ?>//<?php echo e($item->image); ?>" alt=""></td>
                        <td>
                            <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-primary edit"  style="margin: 0px 15px">
                                <i class="ti-pencil"></i>
                            </a>
                            <a data-href="<?php echo e($item->id); ?>" class="btn icon btn-danger remove">
                                <i class="ti-trash"></i>
                            </a>
                        </td>
                            
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>
</div>
<div class="mt-2">
    <?php echo $sliders->render(); ?>

</div>
<?php else: ?>
<p>Không tìm thấy danh mục nào phù hợp</p>
<?php endif; ?>
<?php /**PATH D:\web\web\backend\shopping-cart\resources\views/admin/sliders/read.blade.php ENDPATH**/ ?>
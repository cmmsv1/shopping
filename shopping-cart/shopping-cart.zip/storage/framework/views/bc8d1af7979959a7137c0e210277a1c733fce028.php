<?php $__env->startSection('content'); ?>
<?php
    use App\Models\Category;
    use App\Models\Product;
?>
<main id="main">
    <div class="container">

        <!--MAIN SLIDE-->
        <div class="wrap-main-slide">
            <div class="slide-carousel owl-carousel style-nav-1" data-items="1" data-loop="1" data-nav="true" data-dots="false">
                <div class="item-slide">
                    <img src="<?php echo e(asset('assets/images/main-slider-1-1.jpg')); ?>" alt="" class="img-slide">
                    <div class="slide-info slide-1">
                        <h2 class="f-title">Kid Smart <b>Watches</b></h2>
                        <span class="subtitle">Compra todos tus productos Smart por internet.</span>
                        <p class="sale-info">Only price: <span class="price">$59.99</span></p>
                        <a href="#" class="btn-link">Shop Now</a>
                    </div>
                </div>
                <div class="item-slide">
                    <img src="<?php echo e(asset('assets/images/main-slider-1-2.jpg')); ?>" alt="" class="img-slide">
                    <div class="slide-info slide-2">
                        <h2 class="f-title">Extra 25% Off</h2>
                        <span class="f-subtitle">On online payments</span>
                        <p class="discount-code">Use Code: #FA6868</p>
                        <h4 class="s-title">Get Free</h4>
                        <p class="s-subtitle">TRansparent Bra Straps</p>
                    </div>
                </div>
                <div class="item-slide">
                    <img src="<?php echo e(asset('assets/images/main-slider-1-3.jpg')); ?>" alt="" class="img-slide">
                    <div class="slide-info slide-3 ">
                        <h2 class="f-title">Great Range of <b>Exclusive Furniture Packages</b></h2>
                        <span class="f-subtitle">Exclusive Furniture Packages to Suit every need.</span>
                        <p class="sale-info">Stating at: <b class="price">$225.00</b></p>
                        <a href="#" class="btn-link">Shop Now</a>
                    </div>
                </div>
            </div>
        </div>

        <!--BANNER-->
        <div class="wrap-banner style-twin-default">
            <div class="banner-item">
                <a href="#" class="link-banner banner-effect-1">
                    <figure><img src="<?php echo e(asset('assets/images/home-1-banner-1.jpg')); ?>" alt="" width="580" height="190"></figure>
                </a>
            </div>
            <div class="banner-item">
                <a href="#" class="link-banner banner-effect-1">
                    <figure><img src="<?php echo e(asset('assets/images/home-1-banner-2.jpg')); ?>" alt="" width="580" height="190"></figure>
                </a>
            </div>
        </div>

        <!--On Sale-->
        <?php if(count($products_sale)>0): ?> 
        <div class="wrap-show-advance-info-box style-1 has-countdown">
            <h3 class="title-box">On Sale</h3>
            <div class="wrap-countdown mercado-countdown" data-expire="2020/12/12 12:34:56"></div>
            <div class="wrap-products slide-carousel owl-carousel style-nav-1 equal-container " data-items="5" data-loop="false" data-nav="true" data-dots="false" data-responsive='{"0":{"items":"1"},"480":{"items":"2"},"768":{"items":"3"},"992":{"items":"4"},"1200":{"items":"5"}}'>
                   
                    <?php $__currentLoopData = $products_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                        <div class="product product-style-2 equal-elem ">
                            <div class="product-thumnail">
                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="<?php echo e($item->name); ?>">
                                    <figure><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->image); ?>" width="800" height="800" alt="<?php echo e($item->name); ?>"></figure>
                                </a>
                                <div class="group-flash">
                                    <span class="flash-item sale-label">sale</span>
                                </div>
                                <div class="wrap-btn">
                                    <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="function-link">quick view</a>
                                </div>
                            </div>
                            <div class="product-info">
                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="product-name"><span><?php echo e($item->name); ?></span></a>
                                <div class="wrap-price">
                                    <ins>
                                        <p class="product-price">
                                            <?php
                                                echo number_format($item->sale_price, 0, ',', '.').'đ';
                                            ?>
                                        </p>
                                    </ins> 
                                    <del>
                                        <p class="product-price">
                                            <?php
                                                echo number_format($item->regular_price, 0, ',', '.').'đ';
                                            ?>
                                        </p>
                                    </del>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
        <?php endif; ?>
        <!--Latest Products-->
        <div class="wrap-show-advance-info-box style-1">
            <h3 class="title-box">Latest Products</h3>
            <div class="wrap-top-banner">
                <a href="#" class="link-banner banner-effect-2">
                    <figure><img src="<?php echo e(asset('assets/images/digital-electronic-banner.jpg')); ?>" width="1170" height="240" alt=""></figure>
                </a>
            </div>
            <div class="wrap-products">
                <div class="wrap-product-tab tab-style-1">						
                    <div class="tab-contents">
                        <div class="tab-content-item active" id="digital_1a">
                            <div class="wrap-products slide-carousel owl-carousel style-nav-1 equal-container" data-items="5" data-loop="false" data-nav="true" data-dots="false" data-responsive='{"0":{"items":"1"},"480":{"items":"2"},"768":{"items":"3"},"992":{"items":"4"},"1200":{"items":"5"}}' >
                                <?php $__currentLoopData = $products_latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <div class="product product-style-2 equal-elem ">
                                    <div class="product-thumnail">
                                        <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="<?php echo e($item->name); ?>">
                                            <figure><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->image); ?>" width="800" height="800" alt="<?php echo e($item->name); ?>"></figure>
                                        </a>
                                        <div class="group-flash">
                                            <span class="flash-item new-label">new</span>
                                            <?php if($item->sale_price > 0): ?>
                                                <span class="flash-item sale-label">sale</span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="wrap-btn">
                                            <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="function-link">quick view</a>
                                        </div>
                                    </div>
                                    <div class="product-info">
                                        <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="product-name"><span><?php echo e($item->name); ?></span></a>
                                        <div class="wrap-price">
                                            <?php if($item->sale_price > 0): ?>
                                                <ins>
                                                    <p class="product-price">
                                                        <?php
                                                            echo number_format($item->sale_price, 0, ',', '.').'đ';
                                                        ?>
                                                    </p>
                                                </ins> 
                                                <del>
                                                    <p class="product-price">
                                                        <?php
                                                            echo number_format($item->regular_price, 0, ',', '.').'đ';
                                                        ?>
                                                    </p>
                                                </del>
                                            <?php else: ?>
                                                <span class="product-price">
                                                    <?php
                                                        echo number_format($item->regular_price, 0, ',', '.').'đ';
                                                    ?>
                                                </span>
                                            <?php endif; ?> 
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>							
                    </div>
                </div>
            </div>
        </div>

        <!--Product Categories-->
        <div class="wrap-show-advance-info-box style-1">
            <h3 class="title-box">Product Categories</h3>
            <div class="wrap-top-banner">
                <a href="#" class="link-banner banner-effect-2">
                    <figure><img src="<?php echo e(asset('assets/images/fashion-accesories-banner.jpg')); ?>" width="1170" height="240" alt=""></figure>
                </a>
            </div>
            <div class="wrap-products">
                <div class="wrap-product-tab tab-style-1">
                    <div class="tab-control">
                        <?php $__currentLoopData = $categories_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
                            <a href="#category_<?php echo e($item->id); ?>" data-slug="<?php echo e($item->slug); ?>" class="tab-control-item <?php echo e($loop->index ==0?'active':''); ?>"><?php echo e($item->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-contents" id="tab-contents">
                        <?php $__currentLoopData = $categories_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-content-item <?php echo e($loop->index ==0?'active':''); ?>" id="category_<?php echo e($item->id); ?>">
                                <div class="wrap-products slide-carousel owl-carousel style-nav-1 equal-container" data-items="5" data-loop="false" data-nav="true" data-dots="false" data-responsive='{"0":{"items":"1"},"480":{"items":"2"},"768":{"items":"3"},"992":{"items":"4"},"1200":{"items":"5"}}' >                                  
                                    
                                        <?php
                                            $category_parent_id = $item->id;
                                            $category_chidren_id = Category::getArrayChildren($category_parent_id);
                                            $products = Product::whereIn('category_id', $category_chidren_id)->take(8)->get();
                                        ?>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                        <div class="product product-style-2 equal-elem ">
                                            <div class="product-thumnail">
                                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" title="<?php echo e($item->name); ?>">
                                                    <figure><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($item->image); ?>" width="800" height="800" alt="<?php echo e($item->name); ?>"></figure>
                                                </a>
                                                <div class="group-flash">
                                                    <?php if($item->sale_price > 0): ?>
                                                        <span class="flash-item sale-label">sale</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="wrap-btn">
                                                    <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="function-link">quick view</a>
                                                </div>
                                            </div>
                                            <div class="product-info">
                                                <a href="<?php echo e(route('product.detail',$item->slug)); ?>" class="product-name"><span><?php echo e($item->name); ?></span></a>
                                                <div class="wrap-price">
                                                    <?php if($item->sale_price > 0): ?>
                                                        <ins>
                                                            <p class="product-price">
                                                                <?php
                                                                    echo number_format($item->sale_price, 0, ',', '.').'đ';
                                                                ?>
                                                            </p>
                                                        </ins> 
                                                        <del>
                                                            <p class="product-price">
                                                                <?php
                                                                    echo number_format($item->regular_price, 0, ',', '.').'đ';
                                                                ?>
                                                            </p>
                                                        </del>
                                                    <?php else: ?>
                                                        <span class="product-price">
                                                            <?php
                                                                echo number_format($item->regular_price, 0, ',', '.').'đ';
                                                            ?>
                                                        </span>
                                                    <?php endif; ?> 
                                                </div>
                                            </div>
                                        </div>     
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                              
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </div>
                </div>
            </div>
        </div>			

    </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\web\backend\shopping-cart\resources\views/home/index.blade.php ENDPATH**/ ?>